<a href="http://i.imgur.com/YUhDNh9.png"><img src="http://i.imgur.com/YUhDNh9.png" title="Neutron" /></a>


Neutron is an open source wallet aimed at increasing a holders BTC Value over time with staking features. Now under new Management with active members. The Neutron Network is solid and will be maintained for the forseeable future. Support the network by running a Nucleus Node and earn coin for your efforts! Neutron is obtainable on well known exchanges and can be purchased at market prices. Neutron is easy to Buy, Stake, Trade, and Sell. 


Specs:
        

	Ticker: NTRN
	
	No Premine, No IPO/ICO

	Block time: 79 seconds

	Coinbase maturity: 90 blocks

	PoS Coin Maturity 5h (hiPOS)

	Algo: SHA256d

	RPC Port: 32000

	P2P Port: 32001


Block Rewards:


	Block 0 - 120 = 0 Coins
	
	Block 121 - 950 = 750  Coins

	Block 951  - 1400 = 550 Coins

	Block 1401 - 1900  = 425 Coins

	Block 1901 - 2400 = 325 Coins

	Block 2401 - 2850 = 250 Coins
	
	Block 2600 Starting of the Proof of Stake Phase
	
	Block 2851 - 3500 = 190 Coins

	Block 3501 - 4000 = 105 Coins

	End of PoW Period


Now, for the regular PoS rewards schedule:

	Block 4001 - 5000 = 30 Coins

	Block 5001 - 7000 = 45 Coins

	Block 7001 - 7250 = 190 Coins

	Block 7251 - 8500 = 80 Coins

	Block 8501 - 10000 = 15 Coins

	Block 10001 - 13500 = 30 Coins

	Block 13500 and Up = Regular 7% Annual PoS


For more information about Neutron, please contact bitlabzinc@gmail.com
